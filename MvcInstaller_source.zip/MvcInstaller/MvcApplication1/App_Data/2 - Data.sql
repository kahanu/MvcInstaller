INSERT INTO [dbo].[MyBlogTable] ([Title],[Body],[DateCreated]) VALUES (N'First Title', N'First body description...', '11/12/2010')
INSERT INTO [dbo].[MyBlogTable] ([Title],[Body],[DateCreated]) VALUES (N'Second Title', N'Second body description...', '11/13/2010')
INSERT INTO [dbo].[MyBlogTable] ([Title],[Body],[DateCreated]) VALUES (N'Third Title', N'Third body description...', '11/14/2010')
